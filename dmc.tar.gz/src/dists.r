dir='../results/test1_dist/'
nhe="0"  #he number
is="n"  #if is, left blank, otherwise, put n
tt="1" #total number of steps divided by 10000
dt="15" #time step in a.u.
molname="hfcl" #molname
state="1"  #calculated state 0 for ground state 1 for first exc. st.
nw="500" #number of walkers
dimdat=100 #size of the density matrix in each coordinate
filename=paste(dir,"he_dist",molname,state,"st",nw,"w",nhe,"he"
               ,tt,"tt",dt,"dt",is,"is.dat",sep="")
#filename=paste("hola",sep="")
print(filename)
transpuesta=1
######################################################################
z1dat <- as.matrix(read.table(filename))
z1dat1=as.numeric(z1dat[,1])
z1dat2=as.numeric(z1dat[,2])
z1dat3=as.numeric(z1dat[,3])
dens=as.numeric(z1dat[,4])

print(max(dens))
cont=0
rho<-rep(0,length(z1dat1)/dimdat)

for (i in 1:dimdat)
{
  for (k in 1:dimdat)
  {
    cont=cont+1
    for (j in 1:dimdat)
    {rho[cont]<-rho[cont]+dens[dimdat**2*(i-1)+dimdat*(j-1)+k]
    }
  }
}



  xlimite<-c(min(z1dat1),max(z1dat1))
  ylimite<-c(min(z1dat3),max(z1dat3))
            
 
 zvar<-array(rho,c(length(rho)^(1/2),length(rho)^(1/2)))
 
 if (transpuesta==1) zvar<-t(zvar)
# #Esta opcion se activa si se varía "y", 
#manteniendo "x" fijo (es decir, si x esta en una columna mas a la izquierda que y)
 
 	zlimites<-c(min(zvar),max(zvar))
# 
# 
# 
 plot(1,1,xlim=xlimite,ylim=ylimite,type="n")
# 
# 
# 
 par(new=TRUE,ann=F,xaxs="i",yaxs="i")
# 
 image(y = seq(min(ylimite), max(ylimite), length.out=nrow(zvar))
      ,x =  seq(min(xlimite), max(xlimite), length.out=nrow(zvar)),
      zvar,col=rainbow(100),zlim=zlimites,axes=FALSE)
# 
# par(new=TRUE)
# 
# contour(y = seq(min(ylimite), max(ylimite), length.out=nrow(zvar)),
# 	x =  seq(min(xlimite), max(xlimite), length.out=nrow(zvar)),
#         zvar,col="navy",labcex=0.7,axes=F,nlevels=16,zlim=zlimites,vfont = c("serif", "bold"))
# 
# dev.off()

